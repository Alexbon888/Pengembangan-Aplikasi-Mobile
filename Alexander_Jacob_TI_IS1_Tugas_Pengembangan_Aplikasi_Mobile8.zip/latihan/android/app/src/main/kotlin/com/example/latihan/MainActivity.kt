package com.example.latihan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
